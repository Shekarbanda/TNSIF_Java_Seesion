package assignment;
import java.util.*;
import java.text.*;

public class Main {

	public static void main(String[] args) {
		final DecimalFormat dec = new DecimalFormat("0.00");
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("1. AirIndia");
		System.out.println("2. KingFisher");
		System.out.println("3. Indigo");
		
		System.out.println("Choose your Choice from 1-3 :");
		
		//taking input from user
		int userChoice = scan.nextInt();
		
		switch(userChoice) {
		case 1:
			System.out.println("Enter No.of Hours : ");
			int hour = scan.nextInt();
			System.out.println("Enter Cost Per Hour : ");
			double cost = scan.nextDouble();
			
			//assigning values through constructor
			AirIndia airfareObj = new AirIndia(hour,cost);
			
			//assigning values through setters
//			airfareObj.setHours(hour);
//			airfareObj.setCostPerHour(cost);
			
			double total  = airfareObj.calculateAmount();
			System.out.println(dec.format(total));
			break;
			
		case 2:
			System.out.println("Enter No.of Hours : ");
			hour = scan.nextInt();
			System.out.println("Enter Cost Per Hour : ");
			cost = scan.nextDouble();
			
			//assigning values through constructor
			KingFisher kingfisherObj = new KingFisher(hour,cost);
			
			//assigning values through setters
//			kingfisherObj.setHours(hour);
//			kingfisherObj.setCostPerHour(cost);
			
			total  = kingfisherObj.calculateAmount();
			System.out.println(dec.format(total));
			break;
			
		case 3:
			System.out.println("Enter No.of Hours : ");
			hour = scan.nextInt();
			System.out.println("Enter Cost Per Hour : ");
			cost = scan.nextDouble();
			
			//assigning values through constructor
			Indigo indigoObj = new Indigo(hour,cost);
			
			//assigning values through setters
//			indigoObj.setHours(hour);
//			indigoObj.setCostPerHour(cost);
			
			total  = indigoObj.calculateAmount();
			System.out.println(dec.format(total));
			break;
			
		default:
			System.err.println("Invalid Option");
			break;
		}
		
		scan.close();
	}

}
