package assignment;

public interface Airfare {
	double calculateAmount();
}
